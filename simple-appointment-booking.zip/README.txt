SIMPLIFIED APPOINTMENT REQUEST PAGE

This is the simple version: no database, GitHub, Supabase, or server setup is required.

Customer flow:
1. Open the link you share.
2. Choose a package.
3. Choose a date and time.
4. Enter contact information.
5. See the 50% deposit.
6. Tap the deposit button to open your WiPay link.
7. Pay the deposit.
8. Send the payment screenshot to you.
9. You manually confirm the appointment.

WiPay:
https://tt.wipayfinancial.com/to_me/Jamelia

Packages:
- Standard — TTD $500 / 30 minutes — TTD $250 deposit
- Premium — TTD $750 / 60 minutes — TTD $375 deposit
- VIP — TTD $1,000 / 90 minutes — TTD $500 deposit

IMPORTANT:
This simple version does not have shared live availability. It cannot automatically know that another customer on another phone has already selected a date. You should manually confirm dates after checking your own appointment list/payment screenshots.

The background image is included as 55445.png.
